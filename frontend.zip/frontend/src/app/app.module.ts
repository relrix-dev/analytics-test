import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { ChartModule } from 'angular2-highcharts';
import { AppComponent } from './app.component';
import { ChartComponent } from './chart/chart.component'; 
declare var require:any;
@NgModule({
  declarations: [
    AppComponent,
    ChartComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    ChartModule.forRoot(
      require('highcharts/highstock'),
      require('highcharts/modules/exporting'),
      
      ),
      
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
