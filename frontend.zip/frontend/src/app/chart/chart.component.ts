import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chart',
  templateUrl: './chart.component.html',
  styleUrls: ['./chart.component.css']
})

export class ChartComponent implements OnInit {
  
  options:Object;
  mapoptions: Object;

  constructor() { 
     this.options = {
            title : { text : 'simple chart' },
            
            xAxis:
              {
                categories:["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"],
                title:{text: "Date"}
              },

            yAxis:{
              title:{text: "Price"},
            },
            
            series: [
              {
                data: [29.9, 71.5, 106.4, 129.2,201,323.5,123.4,567.8,123.4,121.3,201.5,215.5]
              }
              ]
        };
        this.mapoptions={
          
            title : { text : 'simple chart' },
            series: [{
                data: [29.9, 71.5, 106.4, 129.2],
            }]
      
        };
      }

  ngOnInit() {
  }

}
