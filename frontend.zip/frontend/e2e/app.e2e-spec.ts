import { DemochartPage } from './app.po';

describe('demochart App', () => {
  let page: DemochartPage;

  beforeEach(() => {
    page = new DemochartPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
